# Syscall Interface (int 0x80)

This document defines the syscall ABI between ELF programs and the kernel.

⚠️ This is a **strict contract**. Any change here must be reflected in both:

* `interrupts.asm` (`isr128_stub`)
* `syscall_regs_t` in `syscall.h`

---

## Invocation

Syscalls are invoked using:

```asm
int 0x80
```

---

## Register Convention

```text
eax = syscall number
ebx = arg1
ecx = arg2
edx = arg3 (reserved for future use)

return value → eax
```

---

## Current Syscalls

### SYS_WRITE (1)

```c
int sys_write(const char* buf, uint32_t len);
```

* Writes `len` bytes from `buf` to terminal
* Returns number of bytes written
* Returns `-1` on error

---

### SYS_EXIT (2)

```c
void sys_exit(int code);
```

* Terminates program execution
* Currently just returns control to caller
* Future: process teardown

---

### SYS_GET_TICKS (3)

```c
uint32_t sys_get_ticks(void);
```

* Returns number of PIT ticks since boot

---

### SYS_PUTC (4)

```c
int sys_putc(char c);
```

* Writes a single character
* Returns 1

---

## Kernel Entry Point

All syscalls are dispatched via:

```c
void syscall_handler_main(syscall_regs_t* regs);
```

---

## Register Frame Layout

This **must match** `isr128_stub`.

Current assembly push order:

```asm
pusha
push ds
push es
push fs
push gs
push esp   ; pointer passed to C
```

Because the stack grows downward, the last item pushed (`gs`) sits at the lowest address — which is where the struct pointer points. Reading the struct from its base therefore gives fields in reverse push order: `gs` first, `eax` last.

Therefore, C struct:

```c
typedef struct syscall_regs {
    unsigned int gs;   // pushed last → lowest address → first field
    unsigned int fs;
    unsigned int es;
    unsigned int ds;

    unsigned int edi;
    unsigned int esi;
    unsigned int ebp;
    unsigned int esp;
    unsigned int ebx;
    unsigned int edx;
    unsigned int ecx;
    unsigned int eax;  // pushed first by pusha → highest address → last field
} syscall_regs_t;
```

---

## ⚠️ Critical Rule

If you change **anything** in `isr128_stub`:

👉 You MUST update `syscall_regs_t` to match.

Failure to do this will:

* corrupt arguments
* break return values
* silently break syscalls (hard to debug)

---

## Userspace Helpers

Defined in:

```c
user_syscall.h
```

Provides:

```c
sys_write(...)
sys_putc(...)
sys_exit(...)
sys_get_ticks(...)
```

---

## Design Notes

* All programs currently run in **ring 0**
* No memory protection yet
* Kernel trusts pointers (unsafe)
* No blocking, no scheduler

---

## Future Extensions

Planned additions:

* SYS_READ
* SYS_SLEEP
* SYS_EXEC
* SYS_ALLOC

Long-term:

* user mode (ring 3)
* copy-from-user validation
* per-process address spaces

---

## Debugging Tips

If syscalls stop working:

1. Check `isr128_stub`
2. Check `syscall_regs_t`
3. Verify register order
4. Test with `SYS_PUTC` first (simplest path)

Common symptom of mismatch:

* garbage output
* only one character prints
* random crashes after `int 0x80`