#ifndef USER_LIB_H
#define USER_LIB_H

#include "user_syscall.h"

typedef unsigned int uint32_t;

static inline uint32_t str_len(const char* s) {
    uint32_t n = 0;
    while (s[n] != '\0') {
        n++;
    }
    return n;
}

static inline void u_puts(const char* s) {
    sys_write(s, str_len(s));
}

static inline void u_putc(char c) {
    sys_putc(c);
}

static inline void put_uint_dec(void (*outc)(char), uint32_t value) {
    char buf[16];
    int i = 0;

    if (value == 0) {
        outc('0');
        return;
    }

    while (value > 0) {
        buf[i++] = '0' + (value % 10);
        value /= 10;
    }

    while (i > 0) {
        outc(buf[--i]);
    }
}

static inline void u_put_uint(uint32_t value) {
    put_uint_dec(u_putc, value);
}

#endif